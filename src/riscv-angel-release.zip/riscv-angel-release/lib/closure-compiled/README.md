This is a minified/compiled version of closure, stripped to only contain 
necessary components (for Long). 

Compiled using https://developers.google.com/closure/library/docs/closurebuilder
