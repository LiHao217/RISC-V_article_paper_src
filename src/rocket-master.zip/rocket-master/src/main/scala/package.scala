// See LICENSE for license details.

package object rocket extends 
  rocket.constants.ScalarOpConstants
{
  val MTVEC = 0x100
  val START_ADDR = MTVEC + 0x100
}
